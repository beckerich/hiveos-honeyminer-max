#!/usr/bin/env bash

khs=12
stats=`echo '
{
	"hs": [],
	"hs_units": "khs",
	"temp": [],
	"fan": [],
	"uptime": 0,
	"ver": "1",
	"bus_numbers": []
}
'`
