#!/usr/bin/env bash

/home/user/hmlabs/hmm
